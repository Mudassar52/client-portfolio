package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.delay

class NoteRepository(private val noteDao: NoteDao) {
    val allNotes: Flow<List<Note>> = noteDao.getAllNotes()
    val notesCount: Flow<Int> = noteDao.getNotesCount()
    val favoriteCount: Flow<Int> = noteDao.getFavoriteNotesCount()

    private val _syncState = MutableStateFlow<SyncStatus>(SyncStatus.Idle)
    val syncState: StateFlow<SyncStatus> = _syncState.asStateFlow()

    suspend fun getNoteById(id: Int): Note? {
        return noteDao.getNoteById(id)
    }

    suspend fun insert(note: Note): Long {
        return noteDao.insertNote(note)
    }

    suspend fun update(note: Note) {
        noteDao.updateNote(note)
    }

    suspend fun delete(note: Note) {
        noteDao.deleteNote(note)
    }

    suspend fun deleteById(id: Int) {
        noteDao.deleteNoteById(id)
    }

    // Simulate Cloud Backup & Sync (Firestore mock with high fidelity)
    suspend fun syncWithCloud(notesList: List<Note>): Boolean {
        _syncState.value = SyncStatus.Syncing(0.1f)
        delay(600)
        _syncState.value = SyncStatus.Syncing(0.4f)
        delay(800)
        _syncState.value = SyncStatus.Syncing(0.8f)
        delay(600)
        _syncState.value = SyncStatus.Success
        delay(1500)
        _syncState.value = SyncStatus.Idle
        return true
    }
}

sealed interface SyncStatus {
    object Idle : SyncStatus
    data class Syncing(val progress: Float) : SyncStatus
    object Success : SyncStatus
    data class Error(val message: String) : SyncStatus
}
