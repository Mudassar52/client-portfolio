package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.NoteViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val noteViewModel: NoteViewModel = viewModel()
            val themeMode by noteViewModel.themeMode.collectAsState()

            MyApplicationTheme(themeMode = themeMode) {
                val navController = rememberNavController()
                
                NavHost(
                    navController = navController,
                    startDestination = "splash"
                ) {
                    composable("splash") {
                        SplashRoute(navController = navController)
                    }

                    composable("home") {
                        HomeRoute(
                            viewModel = noteViewModel,
                            navController = navController
                        )
                    }

                    composable(
                        route = "note_detail/{noteId}",
                        arguments = listOf(navArgument("noteId") { type = NavType.IntType })
                    ) { backStackEntry ->
                        val noteId = backStackEntry.arguments?.getInt("noteId") ?: -1
                        NoteDetailRoute(
                            noteId = noteId,
                            viewModel = noteViewModel,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable("stats") {
                        StatsRoute(
                            viewModel = noteViewModel,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable("settings") {
                        SettingsRoute(
                            viewModel = noteViewModel,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable("auth") {
                        AuthRoute(
                            viewModel = noteViewModel,
                            onBack = { navController.popBackStack() }
                        )
                    }
                }
            }
        }
    }
}
