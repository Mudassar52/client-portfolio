package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class NoteViewModel(application: Application) : AndroidViewModel(application) {
    private val database = NoteDatabase.getDatabase(application)
    private val repository = NoteRepository(database.noteDao())

    // All database notes
    val allNotes: StateFlow<List<Note>> = repository.allNotes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // UI state for search, filters, drawer selections
    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    // Navigation Drawer current filter: "All", "Favorites", "Work", "Personal", "Study", "Ideas", "Important"
    private val _currentFilter = MutableStateFlow("All")
    val currentFilter = _currentFilter.asStateFlow()

    // Filtered state combining: search query, drawer filter status
    val filteredNotes: StateFlow<List<Note>> = combine(allNotes, _searchQuery, _currentFilter) { notes, query, filter ->
        notes.filter { note ->
            val matchesQuery = note.title.contains(query, ignoreCase = true) || 
                               note.content.contains(query, ignoreCase = true)
            val matchesFilter = when {
                filter == "All" -> true
                filter == "Favorites" -> note.isFavorite
                else -> note.category.equals(filter, ignoreCase = true)
            }
            matchesQuery && matchesFilter
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Statistics counts
    val totalNotesCount = repository.notesCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val favoriteNotesCount = repository.favoriteCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val categoryCounts: StateFlow<Map<String, Int>> = allNotes.map { notesList ->
        val map = mutableMapOf("Work" to 0, "Personal" to 0, "Study" to 0, "Ideas" to 0, "Important" to 0)
        notesList.forEach { note ->
            val cat = note.category
            if (map.containsKey(cat)) {
                map[cat] = map[cat]!! + 1
            }
        }
        map
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    // System theme state: "system", "light", "dark"
    private val _themeMode = MutableStateFlow("light") // Default light as requested: "White and Blue theme", White background
    val themeMode = _themeMode.asStateFlow()

    // User authentication status (for Cloud backend sync)
    private val _userState = MutableStateFlow<String?>(null) // null means logged out
    val userState = _userState.asStateFlow()

    // Sync state
    val syncState = repository.syncState

    init {
        // Pre-populate some gorgeous template notes if the base database is empty
        viewModelScope.launch {
            allNotes.take(2).collect { list ->
                if (list.isEmpty()) {
                    insertNote(
                        Note(
                            title = "Welcome to Blue Notes 🖊️",
                            content = "Blue Notes is a clean and hyper-modern Material 3 note-taking space built to help you capture ideas instantly.\n\nKey features:\n• White & Blue Theme\n• Dynamic Grid Visuals\n• Smooth Animations\n• Live stats dashboard\n• Auto-saving drafts\n• Pinned & favorited elements\n\nClick edit to explore more!",
                            category = "Important",
                            isPinned = true,
                            isFavorite = true
                        )
                    )
                    insertNote(
                        Note(
                            title = "Project Launch Roadmap",
                            content = "Timeline and checkpoints:\n1. Finish UX draft with whiteboard assets.\n2. Enable local database migrations and SQLite indexes.\n3. Integrate Cloud Auto-Sync & Backup workflows.",
                            category = "Work"
                        )
                    )
                    insertNote(
                        Note(
                            title = "Creative Writing Prompts",
                            content = "Ideas for next novel:\n- A watchmaker who discovers a gear that turns back time by one second.\n- A world where shadows maintain their own architectural integrity.",
                            category = "Ideas"
                        )
                    )
                }
            }
        }
    }

    // CRUD functions
    fun insertNote(note: Note) {
        viewModelScope.launch {
            repository.insert(note)
        }
    }

    fun updateNote(note: Note) {
        viewModelScope.launch {
            repository.update(note)
        }
    }

    fun deleteNote(note: Note) {
        viewModelScope.launch {
            repository.delete(note)
        }
    }

    fun deleteNoteById(id: Int) {
        viewModelScope.launch {
            repository.deleteById(id)
        }
    }

    suspend fun getNoteById(id: Int): Note? {
        return repository.getNoteById(id)
    }

    fun togglePin(note: Note) {
        viewModelScope.launch {
            repository.update(note.copy(isPinned = !note.isPinned, updatedAt = System.currentTimeMillis()))
        }
    }

    fun toggleFavorite(note: Note) {
        viewModelScope.launch {
            repository.update(note.copy(isFavorite = !note.isFavorite, updatedAt = System.currentTimeMillis()))
        }
    }

    // Search and Drawer Navigation Filter
    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setFilter(filter: String) {
        _currentFilter.value = filter
    }

    // Theme Configurer
    fun setThemeMode(mode: String) {
        _themeMode.value = mode
    }

    // Auth actions (simulation)
    fun loginUser(email: String) {
        _userState.value = email
    }

    fun logoutUser() {
        _userState.value = null
    }

    // Simulated cloud actions
    fun triggerCloudSync() {
        viewModelScope.launch {
            val list = allNotes.value
            repository.syncWithCloud(list)
        }
    }

    // Simulate Backup & Restore
    private val _backupStatus = MutableSharedFlow<String>()
    val backupStatus = _backupStatus.asSharedFlow()

    fun backupNotes() {
        viewModelScope.launch {
            _backupStatus.emit("Backup created on Cloud Server successfully!")
        }
    }

    fun restoreNotes() {
        viewModelScope.launch {
            // Simulated restore action putting dummy note
            insertNote(
                Note(
                    title = "Restored Note ☁️",
                    content = "This note was successfully restored from cloud database backup at ${System.currentTimeMillis()}.\nOffline Sync acts as a powerful backend replication engine.",
                    category = "Personal"
                )
            )
            _backupStatus.emit("Latest cloud backup successfully restored!")
        }
    }

    // Export notes content as string representing TXT file
    fun exportNotesAsText(): String {
        val notes = allNotes.value
        val sb = StringBuilder()
        sb.append("================ BLUE NOTES EXPORT ================\n")
        sb.append("Export Time: 2026-06-04\n")
        sb.append("Total Elements Saved: ${notes.size}\n\n")
        notes.forEach { note ->
            sb.append("-----------------------------\n")
            sb.append("Title: ${note.title}\n")
            sb.append("Category: ${note.category} | ")
            if (note.isPinned) sb.append("[PINNED] ")
            if (note.isFavorite) sb.append("[FAVORITE] ")
            sb.append("\nUpdated At: ${note.updatedAt}\n\n")
            sb.append(note.content)
            sb.append("\n-----------------------------\n\n")
        }
        return sb.toString()
    }
}
