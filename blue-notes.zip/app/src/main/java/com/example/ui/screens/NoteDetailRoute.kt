package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Note
import com.example.ui.viewmodel.NoteViewModel
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteDetailRoute(
    noteId: Int,
    viewModel: NoteViewModel,
    onBack: () -> Unit
) {
    var noteTitle by remember { mutableStateOf("") }
    var noteContent by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Personal") }
    var isPinned by remember { mutableStateOf(false) }
    var isFavorite by remember { mutableStateOf(false) }
    
    var existingNote by remember { mutableStateOf<Note?>(null) }
    var isSavingIndicatorVisible by remember { mutableStateOf(false) }

    val categories = listOf("Work", "Personal", "Study", "Ideas", "Important")
    val categoryColors = mapOf(
        "Work" to Color(0xFF2563EB),
        "Personal" to Color(0xFF10B981),
        "Study" to Color(0xFFF59E0B),
        "Ideas" to Color(0xFF8B5CF6),
        "Important" to Color(0xFFEF4444)
    )

    // Load existing note if matches
    LaunchedEffect(noteId) {
        if (noteId != -1) {
            val note = viewModel.allNotes.value.find { it.id == noteId } ?: viewModel.getNoteById(noteId)
            if (note != null) {
                existingNote = note
                noteTitle = note.title
                noteContent = note.content
                selectedCategory = note.category
                isPinned = note.isPinned
                isFavorite = note.isFavorite
            }
        }
    }

    // Debounced Autosave Effect
    LaunchedEffect(noteTitle, noteContent, selectedCategory, isPinned, isFavorite) {
        // Skip initial load saves
        if (noteId == -1 && noteTitle.isEmpty() && noteContent.isEmpty()) return@LaunchedEffect

        // Delay 1 second of typing silence
        delay(1200)
        isSavingIndicatorVisible = true
        
        val noteToSave = Note(
            id = if (noteId != -1) noteId else (existingNote?.id ?: 0),
            title = noteTitle.ifEmpty { "Untitled" },
            content = noteContent,
            category = selectedCategory,
            isPinned = isPinned,
            isFavorite = isFavorite,
            createdAt = existingNote?.createdAt ?: System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )

        if (noteId != -1 || existingNote != null) {
            viewModel.updateNote(noteToSave)
        } else {
            // Inserting a new note
            viewModel.insertNote(noteToSave)
            // Reload inserted note's ID using matching details
            delay(100)
            val newlyCreated = viewModel.allNotes.value.firstOrNull { it.title == noteTitle && it.category == selectedCategory }
            if (newlyCreated != null) {
                existingNote = newlyCreated
            }
        }
        
        delay(500)
        isSavingIndicatorVisible = false
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = if (noteId == -1) "New Note" else "Edit Note",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        AnimatedVisibility(
                            visible = isSavingIndicatorVisible,
                            enter = fadeIn() + expandHorizontally(),
                            exit = fadeOut() + shrinkHorizontally()
                        ) {
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.primaryContainer)
                                    .padding(horizontal = 8.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.CloudQueue,
                                    "saving",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Autosaved", fontSize = 10.sp, color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = {
                        // Explict save before back navigation
                        val finalNote = Note(
                            id = if (noteId != -1) noteId else (existingNote?.id ?: 0),
                            title = noteTitle.ifEmpty { "Untitled" },
                            content = noteContent,
                            category = selectedCategory,
                            isPinned = isPinned,
                            isFavorite = isFavorite,
                            createdAt = existingNote?.createdAt ?: System.currentTimeMillis(),
                            updatedAt = System.currentTimeMillis()
                        )
                        if (noteId != -1 || existingNote != null) {
                            viewModel.updateNote(finalNote)
                        } else if (noteTitle.isNotEmpty() || noteContent.isNotEmpty()) {
                            viewModel.insertNote(finalNote)
                        }
                        onBack()
                    }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    // Pin Toggle
                    IconButton(onClick = { isPinned = !isPinned }) {
                        Icon(
                            imageVector = if (isPinned) Icons.Default.PushPin else Icons.Outlined.PushPin,
                            contentDescription = "Pin Note",
                            tint = if (isPinned) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                        )
                    }

                    // Favorite Toggle
                    IconButton(onClick = { isFavorite = !isFavorite }) {
                        Icon(
                            imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder,
                            contentDescription = "Favorite Note",
                            tint = if (isFavorite) Color(0xFFEF4444) else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                        )
                    }

                    // Delete Note Action
                    if (noteId != -1 || existingNote != null) {
                        IconButton(onClick = {
                            val idToDelete = if (noteId != -1) noteId else (existingNote?.id ?: 0)
                            viewModel.deleteNoteById(idToDelete)
                            onBack()
                        }) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete Note",
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .padding(horizontal = 20.dp, vertical = 12.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Category capsules selector
            val isDark = MaterialTheme.colorScheme.background == Color(0xFF0B0F19)
            val categoryScrollState = rememberScrollState()
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(categoryScrollState),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { category ->
                    val isSelected = selectedCategory == category
                    val baseColor = categoryColors[category] ?: Color.Gray
                    
                    val bg = if (isSelected) {
                        baseColor
                    } else {
                        if (isDark) MaterialTheme.colorScheme.surface else Color(0xFFF1F5F9)
                    }
                    val textCol = if (isSelected) {
                        Color.White
                    } else {
                        if (isDark) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f) else Color(0xFF475569)
                    }
                    val borderCol = if (isSelected) {
                        baseColor
                    } else {
                        if (isDark) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f) else Color(0xFFE2E8F0)
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(bg)
                            .clickable { selectedCategory = category }
                            .border(1.dp, borderCol, RoundedCornerShape(20.dp))
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (!isSelected) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(baseColor)
                                )
                            }
                            Text(
                                text = category,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = textCol
                            )
                        }
                    }
                }
            }

            // Title Field
            TextField(
                value = noteTitle,
                onValueChange = { noteTitle = it },
                placeholder = { Text("Title", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.3f)) },
                textStyle = TextStyle(
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                ),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    disabledContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                )
            )

            Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f), thickness = 1.dp)

            // Content Rich Editor
            TextField(
                value = noteContent,
                onValueChange = { noteContent = it },
                placeholder = { Text("Start typing notes here...", fontSize = 16.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.3f)) },
                textStyle = TextStyle(
                    fontSize = 16.sp,
                    lineHeight = 24.sp,
                    color = MaterialTheme.colorScheme.onBackground
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .defaultMinSize(minHeight = 400.dp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    disabledContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                )
            )
        }
    }
}
