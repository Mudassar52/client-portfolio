package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BluePrimary = Color(0xFF2563EB)
val BluePrimaryContainer = Color(0xFFDBEAFE)
val BlueSecondary = Color(0xFF1E40AF)
val BlueTertiary = Color(0xFF60A5FA)

val DarkPrimary = Color(0xFF93C5FD)
val DarkPrimaryContainer = Color(0xFF1E3A8A)

val SoftWhite = Color(0xFFFFFFFF)
val SurfaceLight = Color(0xFFF8FAFC)
val TextDark = Color(0xFF0F172A)
val CardBorder = Color(0xFFE2E8F0)

