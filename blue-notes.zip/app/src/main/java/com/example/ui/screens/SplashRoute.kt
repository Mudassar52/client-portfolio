package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.inset
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.navigation.NavController
import kotlinx.coroutines.delay

@Composable
fun SplashRoute(navController: NavController) {
    var startAnimation by remember { mutableStateOf(false) }
    
    // Scale animation for the logo
    val logoScale by animateFloatAsState(
        targetValue = if (startAnimation) 1f else 0.4f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "logo_scale"
    )

    // Translation animation for text
    val textAlpha by animateFloatAsState(
        targetValue = if (startAnimation) 1f else 0f,
        animationSpec = tween(1200, easing = LinearOutSlowInEasing),
        label = "text_alpha"
    )

    LaunchedEffect(key1 = true) {
        startAnimation = true
        delay(1800) // Beautiful 1.8 seconds transition
        navController.navigate("home") {
            popUpTo("splash") { inclusive = true }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color.White,
                        Color(0xFFEFF6FF), // soft blue
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(24.dp)
        ) {
            // Drawn Logo from the description (Notebook & Pen)
            Box(
                modifier = Modifier
                    .size(160.dp)
                    .scale(logoScale)
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height

                    // 1. Draw notebook base card with shadows / corner radiuses
                    drawRoundRect(
                        color = Color(0xFF2563EB),
                        topLeft = Offset(w * 0.15f, h * 0.1f),
                        size = Size(w * 0.65f, h * 0.8f),
                        cornerRadius = CornerRadius(20.dp.toPx(), 20.dp.toPx())
                    )

                    // Inner pages
                    drawRoundRect(
                        color = Color.White,
                        topLeft = Offset(w * 0.22f, h * 0.15f),
                        size = Size(w * 0.54f, h * 0.7f),
                        cornerRadius = CornerRadius(14.dp.toPx(), 14.dp.toPx())
                    )

                    // Page horizontal ruled lines
                    val numLines = 5
                    val lineSpacing = (h * 0.45f) / numLines
                    val startY = h * 0.32f
                    for (i in 0 until numLines) {
                        drawLine(
                            color = Color(0xFFE2E8F0),
                            start = Offset(w * 0.3f, startY + (i * lineSpacing)),
                            end = Offset(w * 0.62f, startY + (i * lineSpacing)),
                            strokeWidth = 3.dp.toPx()
                        )
                    }

                    // 3. Draw binding rings on the side (left side)
                    val numRings = 4
                    val ringSpacing = (h * 0.5f) / numRings
                    val ringStartY = h * 0.22f
                    for (i in 0 until numRings) {
                        drawRoundRect(
                            color = Color(0xFF1D40AF),
                            topLeft = Offset(w * 0.12f, ringStartY + (i * ringSpacing)),
                            size = Size(w * 0.08f, h * 0.04f),
                            cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                        )
                    }

                    // 4. Draw beautiful diagonal blue ink pen crossing the design
                    // Draw pen body
                    drawLine(
                        color = Color(0xFF2563EB),
                        start = Offset(w * 0.5f, h * 0.75f),
                        end = Offset(w * 0.82f, h * 0.25f),
                        strokeWidth = 10.dp.toPx()
                    )
                    // Pen cap band
                    drawLine(
                        color = Color.White,
                        start = Offset(w * 0.72f, h * 0.4f),
                        end = Offset(w * 0.76f, h * 0.34f),
                        strokeWidth = 12.dp.toPx()
                    )
                    // Draw tip (metallic gray / blue point)
                    drawLine(
                        color = Color(0xFF475569),
                        start = Offset(w * 0.51f, h * 0.74f),
                        end = Offset(w * 0.45f, h * 0.83f),
                        strokeWidth = 6.dp.toPx()
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "Blue Notes",
                fontSize = 32.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFF2563EB),
                letterSpacing = 1.sp,
                modifier = Modifier.scale(logoScale)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Capture Thoughts Instantly",
                fontSize = 14.sp,
                color = Color(0xFF475569).copy(alpha = textAlpha),
                fontWeight = FontWeight.Medium,
                letterSpacing = 0.5.sp
            )
        }
    }
}
